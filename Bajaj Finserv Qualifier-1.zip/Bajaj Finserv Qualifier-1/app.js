const express = require('express');
const app = express();

app.use(express.json());

app.post('/bfhl', (req, res) => {
  try {
    const { status, user_id, college_email_id, college_roll_number, numbers, alphabets } = req.body;
    const response = {
      status,
      user_id,
      college_email_id,
      college_roll_number,
      numbers,
      alphabets,
      is_success: true,
    };
    res.json(response);
  }
  catch(error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.get('/bfhl', (req, res) => {
  try {
    const response = {
      operation_code: 1,
    };
    res.status(200).json(response);
  }
  catch(error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.use((req, res, next) => {
  res.status(404).json({ error: 'Route not found' });
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});